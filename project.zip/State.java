import java.util.*;

public class State {
  private int[][] m;

  public State(int size, boolean shuffle){
    int sqr = (int)(Math.sqrt(size));
    m = new int[sqr][sqr];

    int i = 1;
    int colNum = 0;

    if(shuffle == false){
      for(int[] col: m){
        int numNum = 0;

          for(int num: col){
            m[colNum][numNum] = i;
        
            i++;
           numNum++;
          }
          colNum++;
        }
      m[sqr - 1][sqr - 1] = 0;
    }
    
    else{
      ArrayList<Integer> arr = new ArrayList<>();

      for(int x = 1; x < size; x++){
        arr.add(x);
      }
      arr.add(0);
      Collections.shuffle(arr);
      
      int ctr = 0;
      for(int[] col: m){
        int numNum = 0;

          for(int num: col){
            m[colNum][numNum] = arr.get(ctr);
        
            ctr++;
            numNum++;
          }
          colNum++;
        }
        
    }   
  }

  public int[][] getState(){
    return m;
  }
  
  public String printState(){
    String currState = "";

    for(int[] col: m){
      for(int num: col){
        currState += num + " ";
      }
      currState += "\n";
    }

    return currState;
  }

  public void updateState(int[][] m){
    this.m = m;
  }

  public boolean compareState(State s){
    int colNum = 0;
    int i = 1;
    for(int[] col: m){
      int numNum = 0;

      for(int num: col){
        if(num != s.getState()[colNum][numNum]) return false;
        
        i++;
        numNum++;
      }
      colNum++;
    }
    return true;
  }
}







