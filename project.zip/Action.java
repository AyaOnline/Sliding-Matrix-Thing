public class Action {
  public static boolean shiftLeft(State s, int ele){
    if(ele <= 0) return false;
    int[][] m = s.getState();
    int colNum = 0;
    
    for(int[] col: m){
      int numNum = 0;

      for(int num: col){
        if(num == ele){
          try{
            if(m[colNum][numNum - 1] != 0){
              return false;
            }
            else{
              m[colNum][numNum - 1] = num;
              m[colNum][numNum] = 0;
            }
          }
          catch(ArrayIndexOutOfBoundsException e){
            return false;
          }
        }
        numNum++;
      }
      colNum++;
    }

    s.updateState(m);

    return true;
  }

  public static boolean shiftRight(State s, int ele){
    if(ele <= 0) return false;
    int[][] m = s.getState();
    int colNum = 0;
    
    for(int[] col: m){
      int numNum = 0;

      for(int num: col){
        if(num == ele){
          try{
            if(m[colNum][numNum + 1] != 0){
              return false;
            }
            else{
              m[colNum][numNum + 1] = num;
              m[colNum][numNum] = 0;
            }
          }
          catch(ArrayIndexOutOfBoundsException e){
            return false;
          }
        }
        numNum++;
      }
      colNum++;
    }

    s.updateState(m);

    return true;
  }

  public static boolean shiftDown(State s, int ele){
    if(ele <= 0) return false;
    int[][] m = s.getState();
    int colNum = 0;
    
    for(int[] col: m){
      int numNum = 0;

      for(int num: col){
        if(num == ele){
          try{
            if(m[colNum + 1][numNum] != 0){
              return false;
            }
            else{
              m[colNum + 1][numNum] = num;
              m[colNum][numNum] = 0;
            }
          }
          catch(ArrayIndexOutOfBoundsException e){
            return false;
          }
        }
        numNum++;
      }
      colNum++;
    }

    s.updateState(m);

    return true;
  }

  public static boolean shiftUp(State s, int ele){
    if(ele <= 0) return false;
    int[][] m = s.getState();
    int colNum = 0;
    
    for(int[] col: m){
      int numNum = 0;

      for(int num: col){
        if(num == ele){
          try{
            if(m[colNum - 1][numNum] != 0){
              return false;
            }
            else{
              m[colNum - 1][numNum] = num;
              m[colNum][numNum] = 0;
            }
          }
          catch(ArrayIndexOutOfBoundsException e){
            return false;
          }
        }
        numNum++;
      }
      colNum++;
    }

    s.updateState(m);

    return true;
  }
}