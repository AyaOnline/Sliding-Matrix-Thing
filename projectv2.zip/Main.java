import java.util.*;

public class Main {
    public static void main(String[] args) {
      Scanner in = new Scanner(System.in);

      State a = new State(9, false);
      State b = new State(9, true);
      Action action = new Action();

      while(true){
        System.out.println(b.printState());
        System.out.println(action.potActions(b));
        
        System.out.println("Actions:\n-L for Left\n-R for Right\n-U for Up\n-D for Down");
        System.out.println("Enter the direction you want to move in");
        String dir = in.nextLine();

        System.out.print("Enter the number you want to move: ");
        try{
          int chosen = in.nextInt();
          switch(dir){
          case "L"-> action.shiftLeft(b, chosen);
          case "R"-> action.shiftRight(b, chosen);
          case "U"-> action.shiftUp(b, chosen);
          case "D"-> action.shiftDown(b, chosen);
          default -> System.out.println("Please choose the following directions!");
          }

          System.out.println();

          
        }
        catch(Exception e){
          continue;
        }
        finally{
          in.nextLine();
        }

        if(b.compareState(a) == true) break;
      }
      
      System.out.println("You finished the game!");
      System.out.println(b.printState());
    }
}